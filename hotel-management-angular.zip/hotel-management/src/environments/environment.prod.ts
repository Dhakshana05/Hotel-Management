export const environment = {
    production: true,
    apiUrl: 'https://your-production-api.com/api' // Update with production backend URL
  };
  