import { Component, OnInit } from '@angular/core';
import { HotelService } from '../../services/hotel.service';
// import { HotelService } from './services/hotel.service';
import { AuthService } from '../../services/auth.service'; 
import { RouterModule } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-hotel-list',
  templateUrl: './hotel-list.component.html',
  styleUrls: ['./hotel-list.component.scss']
})
export class HotelListComponent implements OnInit {
  hotels: any[] = [];
  isAdmin: boolean = true;

  constructor(private hotelService: HotelService, private authService: AuthService) {}

  ngOnInit(): void {
    this.fetchHotels();
    const role = this.authService.getUserRole();
    this.isAdmin = role === 'ADMIN';
  }
  
  ngOnInitload() {
    this.loadHotels();
  }

  fetchHotels(): void {
    this.hotelService.getAllHotels().subscribe(data => {
      this.hotels = data;
    });
  }

  loadHotels() {
    this.hotelService.getAllHotels().subscribe(data  => {
      this.hotels = data;
    });
  }

  deleteHotel(hotelId: number): void {
    if (confirm('Are you sure you want to delete this hotel?')) {
      this.hotelService.deleteHotel(hotelId).subscribe(() => {
        this.hotels = this.hotels.filter(h => h.id !== hotelId);
      });
    }
  }
}
