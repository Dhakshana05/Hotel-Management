import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
 
@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, RouterModule, ReactiveFormsModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent implements OnInit {
 
  signupForm!: FormGroup;
  msg: string = ''; // Define msg
 
  private http = inject(HttpClient);
 
  constructor(private fb: FormBuilder, private router: Router) {}
 
  ngOnInit(): void {
    this.signupForm = this.fb.group({
      name: ['', Validators.required],
      username: ['', Validators.required],
      password: ['', Validators.required],
      address: ['', Validators.required],
      mobileno: ['', Validators.required],
      age: ['', [Validators.required, Validators.min(18)]]
    });
}
onSubmit() {
  if (this.signupForm.valid) {
    this.http.post('http://localhost:8000/api/auth/register/user', this.signupForm.value, { responseType: 'text' }) 
    .subscribe({
      next: (response) => {
        console.log('Registration successful:', response);
        this.msg = response; // Use plain text response
       // ✅ Redirect to login page after 2 seconds
       setTimeout(() => {
        this.router.navigate(['/login']);
      }, 2000);},
      error: (error) => {
        console.error('Registration failed:', error);
        this.msg = 'Registration failed: ' + error.message;
      }
    });
  } else {
    this.msg = 'Please fill out the form correctly.';
  }
}

}