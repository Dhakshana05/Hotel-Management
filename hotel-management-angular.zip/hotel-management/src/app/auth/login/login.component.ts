import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { inject } from '@angular/core';
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, RouterModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  userForm!: FormGroup;  // Ensure this property exists
  private http = inject(HttpClient);
  constructor(private fb: FormBuilder, private router: Router) {}
 
  ngOnInit(): void {
    this.userForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }
 
  login() {
    if (this.userForm.valid) {
      this.http.post('http://localhost:8000/api/auth/login', this.userForm.value)
        .subscribe({
          next: (response) => {
            console.log('Login Success:', response);
            this.router.navigate(['/home']); // ✅ Navigate only after success
          },
          error: (error) => console.error('Login Failed:', error)
        });
    } else {
      console.log('Form is invalid');
    }
  }
  adminLogin() {
    console.log('Admin login clicked');
    // Implement admin login logic here
  }}