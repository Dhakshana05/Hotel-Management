import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
// import { ReviewService } from 'src/app/services/review.service';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { ReviewService } from '../../../services/review.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-review-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule], // Keeping only necessary modules
  templateUrl: './review-form.component.html',
  styleUrls: ['./review-form.component.css']
})
export class ReviewFormComponent implements OnInit {
  reviewForm!: FormGroup;
  isEdit = false;
  reviewId!: number;

  constructor(
    private fb: FormBuilder,
    private reviewService: ReviewService,
    private route: ActivatedRoute,
    public router: Router
  ) {}

  ngOnInit(): void {
    this.reviewForm = this.fb.group({
      reservationId: ['', Validators.required],
      rating: ['', [Validators.required, Validators.min(1), Validators.max(5)]],
      comment: ['', Validators.required],
      reviewDate: ['', Validators.required]
    });

    this.reviewId = Number(this.route.snapshot.paramMap.get('id'));
    if (this.reviewId) {
      this.isEdit = true;
      this.reviewService.getAllReviews().subscribe(reviews => {
        const review = reviews.find((r: any) => r.reviewId === this.reviewId);
        if (review) {
          this.reviewForm.patchValue(review);
        }
      });
    }
  }

  cancel(): void {
    this.router.navigate(['/review']);
  }
  
  submitForm(): void {
    if (this.isEdit) {
      this.reviewService.updateReview(this.reviewId, this.reviewForm.value).subscribe(() => {
        this.router.navigate(['/review']);
      });
    } else {
      this.reviewService.addReview(this.reviewForm.value).subscribe(() => {
        this.router.navigate(['/review']);
      });
    }
  }
}
