import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { RoomService } from 'src/app/services/room.service';
import { ActivatedRoute, Router } from '@angular/router';
import { RoomService } from '../../../services/room.service';

@Component({
  selector: 'app-room-form',
  templateUrl: './room-form.component.html',
  styleUrls: ['./room-form.component.scss']
})
export class RoomFormComponent implements OnInit {
  roomForm!: FormGroup;
  roomId!: number;
  isEditMode: boolean = false;

  constructor(
    private fb: FormBuilder,
    private roomService: RoomService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.roomForm = this.fb.group({
      roomType: ['', Validators.required],
      available: [true]
    });

    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEditMode = true;
      this.roomId = +id;
      this.roomService.getRoomById(this.roomId).subscribe((data) => {
        this.roomForm.patchValue(data);
      });
    }
  }

  submitForm(): void {
    if (this.isEditMode) {
      this.roomService.updateRoom(this.roomId, this.roomForm.value).subscribe(() => {
        this.router.navigate(['/room']);
      });
    } else {
      this.roomService.addRoom(this.roomForm.value).subscribe(() => {
        this.router.navigate(['/room']);
      });
    }
  }
}