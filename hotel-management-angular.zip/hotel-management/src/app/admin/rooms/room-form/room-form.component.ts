import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
// import { RoomService } from 'src/app/services/room.service';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { RoomService } from '../../../services/room.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-room-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule], // Added required modules
  templateUrl: './room-form.component.html',
  styleUrls: ['./room-form.component.scss']
})
export class RoomFormComponent implements OnInit {
  roomForm!: FormGroup;
  roomId!: number;
  isEdit: boolean = false;

  constructor(
    private fb: FormBuilder,
    private roomService: RoomService,
    private route: ActivatedRoute,
    private router: Router
  ) { 
    const url = window.location.href;
    this.isEdit = url.includes('edit');
    this.roomForm = this.fb.group({
      roomType: [''],
      available: [false]
    });
  }

  ngOnInit(): void {
    this.roomForm = this.fb.group({
      type: ['', Validators.required],
      price: [0, [Validators.required, Validators.min(1)]],
      available: [false]
    });

    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      this.roomId = +id;
      this.roomService.getRoomById(this.roomId).subscribe((data) => {
        this.roomForm.patchValue(data);
      });

      // ✅ Detect edit mode
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.isEdit = true;
      }
    });
    }
  }

  saveRoom(): void {
    if (this.roomForm.valid) {
      console.log('Room Data:', this.roomForm.value);
    }
  }
  
  submitForm(): void {
    if (this.isEdit) {
      this.roomService.updateRoom(this.roomId, this.roomForm.value).subscribe(() => {
        this.router.navigate(['/room']);
      });
    } else {
      this.roomService.addRoom(this.roomForm.value).subscribe(() => {
        this.router.navigate(['/room']);
      });
    }
  }
}