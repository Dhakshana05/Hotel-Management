import { Component, OnInit } from '@angular/core';
import { RoomService } from '../../../services/room.service';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-room-list',
  templateUrl: './room-list.component.html',
  styleUrls: ['./room-list.component.scss']
})
export class RoomListComponent implements OnInit {
  rooms: any[] = [];
  isAdmin: boolean = false;

  constructor(private roomService: RoomService, private authService: AuthService) {}

  ngOnInit(): void {
    this.fetchRooms();
    this.isAdmin = this.authService.getUserRole() === 'ADMIN';
  }

  // fetchRooms() {
  //   throw new Error('Method not implemented.');
  // }

  fetchRooms(): void {
    this.roomService.getRooms().subscribe(data => {
      this.rooms = data;
    });
  }

  loadRooms() {
    this.roomService.getRooms().subscribe((data) => {
      this.rooms = data;
    });
  }

  deleteRoom(roomId: number): void {
    if (confirm('Are you sure you want to delete this room?')) {
      this.roomService.deleteRoom(roomId).subscribe(() => {
        this.rooms = this.rooms.filter(r => r.id !== roomId);
      });
    }
  }
}
