import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterModule, Router } from '@angular/router';
import { HotelService } from '../../../services/hotel.service';
import { AuthService } from '../../../services/auth.service';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

@Component({
  selector: 'app-hotel-list',
  standalone: true,
  imports: [CommonModule, RouterModule, ReactiveFormsModule, FormsModule],
  templateUrl: './hotel-list.component.html',
  styleUrl: './hotel-list.component.css'
})
export class HotelListComponent implements OnInit {
  hotels: any[] = [];
  filteredHotelsList: any[] = [];
  uniqueLocations: string[] = [];
  uniqueRoomTypes: string[] = [];
  uniqueAmenities: string[] = [];
  uniqueHotelNames: string[] = [];

  selectedLocation: string = '';
  selectedRoomType: string = '';
  selectedAmenity: string = '';
  selectedHotel: string = '';

  isAdmin: boolean = false;

  constructor(
    private hotelService: HotelService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.fetchHotels();
    this.checkAdminRole();
  }

  checkAdminRole(): void {
    this.isAdmin = this.authService.getUserRole() === 'ADMIN';
  }
  
  fetchHotels(): void {
    this.hotelService.getAllHotels().subscribe((data) => {
      this.hotels = data;
      this.filteredHotelsList = [...data];
      this.extractUniqueFilters();
    });
  }

  extractUniqueFilters(): void {
    this.uniqueLocations = [...new Set(this.hotels.map(hotel => hotel.location))];
    this.uniqueRoomTypes = [...new Set(this.hotels.map(hotel => hotel.roomType))];
    this.uniqueAmenities = [...new Set(this.hotels.flatMap(hotel => hotel.amenities))];
    this.uniqueHotelNames = [...new Set(this.hotels.map(hotel => hotel.name))];
  }

  filterHotels(): void {
    this.filteredHotelsList = this.hotels.filter(hotel =>
      (!this.selectedLocation || hotel.location === this.selectedLocation) &&
      (!this.selectedRoomType || hotel.roomType === this.selectedRoomType) &&
      (!this.selectedAmenity || hotel.amenities.includes(this.selectedAmenity)) &&
      (!this.selectedHotel || hotel.name === this.selectedHotel)
    );
  }

  deleteHotel(hotelId: number): void {
    if (confirm('Are you sure you want to delete this hotel?')) {
      this.hotelService.deleteHotel(hotelId).subscribe(() => {
        this.hotels = this.hotels.filter(h => h.id !== hotelId);
        this.filterHotels();
      });
    }
  }

  goToReservation(hotelId: number): void {
    this.router.navigate(['/reservation', hotelId]);
  }
}