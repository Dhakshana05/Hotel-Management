import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminRoutingModule } from './admin-routing.module';
import { ReservationListComponent } from './reservations/reservation-list/reservation-list.component';
import { RouterModule } from '@angular/router';
// import { NgChartsModule } from 'ng2-charts';


@NgModule({
  declarations: [
    ReservationListComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    RouterModule,
    // NgChartsModule
  ]
})
export class AdminModule { }
