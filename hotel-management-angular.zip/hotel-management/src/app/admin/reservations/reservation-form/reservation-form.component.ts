import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
// import { ReservationService } from 'src/app/services/reservation.service';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { ReservationService } from '../../../services/reservation.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-reservation-form',
  standalone: true,
  imports: [CommonModule,RouterModule, ReactiveFormsModule],
  templateUrl: './reservation-form.component.html',
  styleUrls: ['./reservation-form.component.css']
})
export class ReservationFormComponent implements OnInit {
  reservationForm!: FormGroup;
  reservationId!: number;
  isEditMode: boolean = false;

  constructor(
    private fb: FormBuilder,
    private reservationService: ReservationService,
    private route: ActivatedRoute,
    public router: Router
  ) {}

  ngOnInit(): void {
    this.reservationForm = this.fb.group({
      guestName: ['', Validators.required],
      roomId: ['', Validators.required],
      checkInDate: ['', Validators.required],
      checkOutDate: ['', Validators.required]
    });

    this.reservationId = Number(this.route.snapshot.paramMap.get('id'));
    if (this.reservationId) {
      this.isEditMode = true;
      this.reservationService.getReservationById(this.reservationId).subscribe(data => {
        this.reservationForm.patchValue(data);
      });
    }
  }

  submitForm(): void {
    if (this.isEditMode) {
      this.reservationService.updateReservation(this.reservationId, this.reservationForm.value).subscribe(() => {
        this.router.navigate(['/reservation']);
      });
    } else {
      this.reservationService.addReservation(this.reservationForm.value).subscribe(() => {
        this.router.navigate(['/reservation']);
      });
    }
  }
}