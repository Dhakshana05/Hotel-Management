import { ApplicationConfig, importProvidersFrom } from '@angular/core';
import { provideRouter, withComponentInputBinding } from '@angular/router';
import { provideHttpClient, withInterceptors, withInterceptorsFromDi } from '@angular/common/http';
import { authInterceptor } from './interceptors/auth.interceptor';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { HotelService } from './services/hotel.service';
import { FormsModule } from '@angular/forms';
// import { MatFormFieldModule } from '@angular/material/form-field';
// import { MatInputModule } from '@angular/material/input';
// import { MatButtonModule } from '@angular/material/button';
// import { MatIconModule } from '@angular/material/icon';
// import { MatTableModule } from '@angular/material/table';
// import { MatCheckboxModule } from '@angular/material/checkbox';
// import { MatSelectModule } from '@angular/material/select';
// import { MatCardModule } from '@angular/material/card';
// import { MatToolbarModule } from '@angular/material/toolbar';
import { RouterModule } from '@angular/router';
import { provideToastr } from 'ngx-toastr';
import { BrowserAnimationsModule, provideAnimations } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { routes } from './app.routes';
// import { MatDialogModule } from '@angular/material/dialog';
// import { MatSnackBarModule } from '@angular/material/snack-bar';

export const appConfig: ApplicationConfig = {
  providers: [
    importProvidersFrom( 
      // MatFormFieldModule,
      // MatInputModule,
      // MatButtonModule,
      // MatIconModule,
      // MatTableModule,
      // MatCheckboxModule,
      // MatSelectModule,
      // MatCardModule,
      // MatToolbarModule,
      // MatDialogModule,
      // MatSnackBarModule,
      ReactiveFormsModule,
      FormsModule,
      BrowserAnimationsModule,
      (RouterModule.forRoot(routes)),
    ),
    // provideRouter(routes, withComponentInputBinding()),
    // provideHttpClient(withInterceptors([authInterceptor])), provideAnimationsAsync(),
    provideHttpClient(withInterceptorsFromDi()),
    provideRouter(routes, withComponentInputBinding()), 
    provideToastr(), 
    // provideAnimations(), 
    // provideAnimationsAsync(),
    // appRouting,
  ],
};
