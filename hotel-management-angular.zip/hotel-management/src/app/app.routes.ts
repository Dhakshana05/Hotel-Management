import { provideRouter, Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';
// import { HotelListComponent } from './hotel/hotel-list/hotel-list.component';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { AuthGuard } from './guards/auth.guard';
import { AdminGuard } from './guards/admin.guard';
import { HomeComponent } from './admin/home/home.component';
import { HotelFormComponent } from './admin/hotels/hotel-form/hotel-form.component';
import { RoomListComponent } from './admin/rooms/room-list/room-list.component';
import { RoomFormComponent } from './admin/rooms/room-form/room-form.component';
import { ReservationListComponent } from './admin/reservations/reservation-list/reservation-list.component';
import { ReservationFormComponent } from './admin/reservations/reservation-form/reservation-form.component';
import { PaymentListComponent } from './admin/payments/payment-list/payment-list.component';
import { PaymentFormComponent } from './admin/payments/payment-form/payment-form.component';
import { ReviewListComponent } from './admin/reviews/review-list/review-list.component';
import { ReviewFormComponent } from './admin/reviews/review-form/review-form.component';
import { DashboardComponent } from './admin/dashboard/dashboard.component';
import { HotelListComponent } from './admin/hotels/hotel-list/hotel-list.component';

// export const routingProviders = provideRouter(routes);  // ✅ Provide routing

export const routes: Routes = [
  { 
    path: 'login', component: LoginComponent 
  },
  { 
    path: 'register', component: RegisterComponent 
  },{ 
    path: 'home', component: HomeComponent 
  },
  { 
    path: 'hotel', component: HotelListComponent 
  },
  { 
    path: 'admin', component: AdminDashboardComponent, canActivate: [AdminGuard],
    children: [
        { 
          path: 'home', component: HomeComponent 
        },
        { 
          path: '', redirectTo: 'home', pathMatch: 'full' 
        }
      ]
   },
  { 
    path: '', redirectTo: 'login', pathMatch: 'full' 
  },
  { 
    path: '**', redirectTo: 'login' 
  },
  {
    path: 'admin/hotel', component: HotelListComponent, canActivate: [AdminGuard]
  },
  {
    path: 'admin/hotel/add', component: HotelFormComponent, canActivate: [AdminGuard]
  },
  {
    path: 'admin/hotel/edit/:id', component: HotelFormComponent, canActivate: [AdminGuard]
  },
  {
    path: 'admin/rooms', component: RoomListComponent, canActivate: [AdminGuard]
  },
  {
    path: 'admin/rooms/add', component: RoomFormComponent, canActivate: [AdminGuard]
  },
  {
    path: 'admin/rooms/edit/:id', component: RoomFormComponent, canActivate: [AdminGuard]
  },
  {
    path: 'admin/reservations', component: ReservationListComponent, canActivate: [AdminGuard]
  },
  {
    path: 'admin/reservations/add', component: ReservationFormComponent, canActivate: [AdminGuard]
  },
  {
    path: 'admin/reservations/edit/:id', component: ReservationFormComponent, canActivate: [AdminGuard]
  },  
  {
    path: 'admin/payments', component: PaymentListComponent, canActivate: [AdminGuard]
  },
  {
    path: 'admin/payments/add', component: PaymentFormComponent, canActivate: [AdminGuard]
  },
  {
    path: 'admin/payments/edit/:id', component: PaymentFormComponent, canActivate: [AdminGuard]
  },
  {
    path: 'admin/reviews', component: ReviewListComponent, canActivate: [AdminGuard]
  },
  {
    path: 'admin/reviews/add', component: ReviewFormComponent, canActivate: [AdminGuard]
  },
  {
    path: 'admin/reviews/edit/:id', component: ReviewFormComponent, canActivate: [AdminGuard]
  },    
  {
    path: 'admin/dashboard', component: DashboardComponent, canActivate: [AdminGuard]
  },  
  { 
    path: 'admin', component: AdminDashboardComponent, canActivate: [AuthGuard], data: { role: 'ADMIN' } 
  },
  {
    path: 'hotel', component: HotelListComponent 
  },
  { 
    path: 'hotel/add', component: HotelFormComponent, canActivate: [AuthGuard], data: { role: 'ADMIN' } 
  },
  { 
    path: 'hotel/edit/:id', component: HotelFormComponent, canActivate: [AuthGuard], data: { role: 'ADMIN' } 
  },
  { 
    path: 'room', component: RoomListComponent 
  },
  { 
    path: 'room/add', component: RoomFormComponent, canActivate: [AuthGuard], data: { role: 'ADMIN' } 
  },
  { 
    path: 'room/edit/:id', component: RoomFormComponent, canActivate: [AuthGuard], data: { role: 'ADMIN' } 
  },
  { 
    path: 'reservation', component: ReservationListComponent 
  },
  { 
    path: 'reservation/add', component: ReservationFormComponent, canActivate: [AuthGuard], data: { role: 'ADMIN' } 
  },
  { 
    path: 'reservation/edit/:id', component: ReservationListComponent 
  },
  { 
    path: 'payment', component: PaymentListComponent 
  },
  { 
    path: 'payment/add', component: PaymentFormComponent, canActivate: [AuthGuard], data: { role: 'ADMIN' } 
  },
  { 
    path: 'payment/edit/:id', component: PaymentFormComponent, canActivate: [AuthGuard], data: { role: 'ADMIN' } 
  },
  { 
    path: 'review', component: ReviewListComponent 
  },
  { 
    path: 'review/add', component: ReviewFormComponent, canActivate: [AuthGuard] 
  },
  { 
    path: 'review/edit/:id', component: ReviewFormComponent, canActivate: [AuthGuard], data: { role: 'ADMIN' } 
  },
  { 
    path: 'hotel/list', component: HotelListComponent 
  },
  { 
    path: 'hotel/edit/:id', component: HotelListComponent 
  },
  { 
    path: '', redirectTo: '/hotels', pathMatch: 'full' 
  }
];
