import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RoomService {
  private apiUrl = 'http://localhost:8000/api/room';

  constructor(private http: HttpClient) {}

  getRooms(): Observable<any> {
    return this.http.get(`${this.apiUrl}/all`);
  }

  getRoomById(roomId: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/${roomId}`);
  }

  addRoom(room: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/post`, room);
  }

  updateRoom(roomId: number, room: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/update/${roomId}`, room);
  }

  deleteRoom(roomId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/delete/${roomId}`);
  }

  checkAvailability(roomTypeId: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/available/${roomTypeId}`);
  }
}
