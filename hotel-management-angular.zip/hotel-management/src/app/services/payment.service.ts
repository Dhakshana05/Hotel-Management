import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {
  private apiUrl = 'http://localhost:8000/api/payment';

  constructor(private http: HttpClient) {}

  getPayments(): Observable<any> {
    return this.http.get(`${this.apiUrl}/all`);
  }

  getPaymentById(paymentId: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/${paymentId}`);
  }

  addPayment(payment: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/post`, payment);
  }

  updatePayment(paymentId: number, payment: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/${paymentId}`, payment);
  }

  deletePayment(paymentId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${paymentId}`);
  }

  getPaymentsByStatus(status: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/status/${status}`);
  }

  getTotalRevenue(): Observable<number> {
    return this.http.get<number>(`${this.apiUrl}/total-revenue`);
  }
}