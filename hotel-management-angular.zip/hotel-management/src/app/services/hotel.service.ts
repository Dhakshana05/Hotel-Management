import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class HotelService {
  private apiUrl = 'http://localhost:8000/api/hotel';

  constructor(private http: HttpClient) {}

  getAllHotels(): Observable<any> {
    const token = 'eyJhbGciOiJIUzI1NiJ9.eyJyb2xlIjoiVVNFUiIsInN1YiI6I…Tg4fQ.oI-lzrQcUOFu-kHUwYpVs5FbpU-j7dHtNtJQHeBg3Rc'; // Replace with the actual token
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    
    return this.http.get(`${this.apiUrl}/all`, { headers });
  }

  getHotelById(id: number): Observable<any> {
    const token = 'your-bearer-token-here'; // Replace with the actual token
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    
    return this.http.get(`${this.apiUrl}/${id}`, { headers });
  }

  addHotel(hotel: any): Observable<any> {
    const token = 'your-bearer-token-here'; // Replace with the actual token
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    
    return this.http.post(`${this.apiUrl}/post`, hotel, { headers });
  }

  updateHotel(id: number, hotel: any): Observable<any> {
    const token = 'your-bearer-token-here'; // Replace with the actual token
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    
    return this.http.put(`${this.apiUrl}/update/${id}`, hotel, { headers });
  }

  deleteHotel(id: number): Observable<any> {
    const token = 'your-bearer-token-here'; // Replace with the actual token
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    
    return this.http.delete(`${this.apiUrl}/delete/${id}`, { headers });
  }
}