import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HotelService {
  private apiUrl = 'http://localhost:8000/api/hotel';

  constructor(private http: HttpClient) {}

  getAllHotels(): Observable<any> {
    return this.http.get(`${this.apiUrl}/all`);
  }

  getHotelById(id: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/${id}`);
  }

  addHotel(hotel: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/post`, hotel);
  }

  updateHotel(id: number, hotel: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/update/${id}`, hotel);
  }

  deleteHotel(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/delete/${id}`);
  }
}
