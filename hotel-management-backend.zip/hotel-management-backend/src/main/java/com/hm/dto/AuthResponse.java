package com.hm.dto;
 
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
 
@Getter
@Setter
@AllArgsConstructor
public class AuthResponse {
    private String token;
}
 
 
 
//package com.hm.dto;
//
//import lombok.AllArgsConstructor;
//import lombok.Getter;
//
//@Getter
//@AllArgsConstructor
//public class AuthResponse {
//    private String token;
//}