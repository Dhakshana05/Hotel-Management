package com.hm.controller;
 
import com.hm.dto.AuthRequest;
import com.hm.dto.AuthResponse;
import com.hm.dto.SignUp;
import com.hm.entity.User;
import com.hm.repository.UserRepository;
import com.hm.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
@CrossOrigin(origins = "http://localhost:8000")
@RestController
@RequestMapping("/api/auth")
public class AuthController {
 
    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
 
    @Autowired
    public AuthController(AuthenticationManager authenticationManager, UserRepository userRepository,
                          PasswordEncoder passwordEncoder, JwtUtil jwtUtil) {
        this.authenticationManager = authenticationManager;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }
 
	/*
	 * @PostMapping("/register/user") public ResponseEntity<String>
	 * register(@RequestBody AuthRequest request) { User user = new User();
	 * user.setUsername(request.getUsername());
	 * user.setPassword(passwordEncoder.encode(request.getPassword()));
	 * user.setRole("USER"); user.setName(request.getUsername()); // ✅ Set the name
	 * to avoid null issues
	 * 
	 * userRepository.save(user); return
	 * ResponseEntity.ok("User registered successfully"); }
	 */
 
    @PostMapping("/register/user")
    public ResponseEntity<String> registerUser(@RequestBody SignUp request) {
    	System.out.println("FRom signUpBoot : "+request);
        if (userRepository.findByUsername(request.getUsername()).isPresent()) {
            return ResponseEntity.badRequest().body("Username is already taken");
        }
		
		  User user = new User(); // // user.setUsername(request.getUsername()); //
		  user.setAge(request.getAge());
		  user.setMobileno(request.getMobileno());
		  user.setAddress(request.getAddress());
		  user.setPassword(passwordEncoder.encode(request.getPassword()));
		  user.setRole("USER"); // 👤 Assign "USER" role //
		  System.out.println("User date : "+user);
		  user.setName(request.getName());
		  user.setUsername(request.getUsername());
		  
		  
		         userRepository.save(user);
        return ResponseEntity.ok("User registered successfully");
    }
 
    
    @PostMapping("/register/admin")
    public ResponseEntity<String> registerAdmin(@RequestBody AuthRequest request) {
        if (userRepository.findByUsername(request.getUsername()).isPresent()) {
            return ResponseEntity.badRequest().body("Username is already taken");
        }
        User admin = new User();
        admin.setUsername(request.getUsername());
        admin.setPassword(passwordEncoder.encode(request.getPassword()));
        admin.setRole("ADMIN");  // 🔥 Assign "ADMIN" role
        admin.setName(request.getUsername());
        userRepository.save(admin);
        return ResponseEntity.ok("Admin registered successfully");
    }
 
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest request) {
    	//request.setRole("ROle_USER");
    	System.out.println("login page : "+request);
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));
 
        User userDetails = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));
 
        String token = jwtUtil.generateToken(userDetails);
        return ResponseEntity.ok(new AuthResponse(token));
    }
}
 
 
//Register
//http://localhost:8000/api/auth/register
//{
//    "username": "admin",
//    "password": "admin123",
//    "role": "ADMIN"
//}
 
//http://localhost:8000/api/auth/login [{
//"username": "admin",
//"password": "admin123"}]
 
 
//package com.hm.controller;
//
//import com.hm.dto.AuthRequest;
//import com.hm.dto.AuthResponse;
//import com.hm.entity.User;
//import com.hm.repository.UserRepository;
//import com.hm.security.JwtUtil;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@RequestMapping("/api/auth")
//public class AuthController {
//    
//    private final AuthenticationManager authenticationManager;
//    private final UserRepository userRepository;
//    private final PasswordEncoder passwordEncoder;
//    private final JwtUtil jwtUtil;
//
//    @Autowired
//    public AuthController(AuthenticationManager authenticationManager, UserRepository userRepository,
//                          PasswordEncoder passwordEncoder, JwtUtil jwtUtil) {
//        this.authenticationManager = authenticationManager;
//        this.userRepository = userRepository;
//        this.passwordEncoder = passwordEncoder;
//        this.jwtUtil = jwtUtil;
//    }
//
//    @PostMapping("/register")
//    public ResponseEntity<String> register(@RequestBody AuthRequest request) {
//        User user = new User();
//        user.setUsername(request.getUsername());
//        user.setPassword(passwordEncoder.encode(request.getPassword()));
//        user.setRole("USER");
//        user.setName(request.getUsername());
//       // user.set
//        userRepository.save(user);
//        return ResponseEntity.ok("User registered successfully");
//    }
//
//    @PostMapping("/login")
//    public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest request) {
//        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));
//
//        User userDetails = userRepository.findByUsername(request.getUsername())
//                .orElseThrow(() -> new RuntimeException("User not found"));
//
//        String token = jwtUtil.generateToken(userDetails);
//        return ResponseEntity.ok(new AuthResponse(token));
//    }
//}